Tanda Bellamente mini web

Contenido:
- index.html
- manifest.json
- sw.js

Sube la carpeta a Netlify, Vercel o GitHub Pages.
